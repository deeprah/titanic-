# Titanic Dataset - Exploratory Data Analysis

This repository contains an in-depth exploratory data analysis on the Titanic dataset, focusing on:

- Understanding variable distributions
- Identifying missing values
- Detecting outliers
- Exploring relationships between features

## Files
- eda.ipynb: Jupyter notebook with the complete analysis
- data/titanic.csv: The dataset used
- requirements.txt: Required Python packages

---

Author: [Your Name]
